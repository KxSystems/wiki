<?php
/** Samogitian
 *
 * ISO 639-3 code 'sgs' should be used. This is code is maintained for backward
 * compatilibity.
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'sgs';
